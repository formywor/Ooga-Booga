# Project Z Modern 0.1.1 — separate HTA experiment

Project Z Modern does not replace Project Z. It is a separate standalone HTA
that reuses the same ScriptNovaa account, registered computer, and `Z-` tokens.

It launches the installed Microsoft Edge browser in a dedicated profile and
keeps an HTA session controller open. This gives websites a current Chromium
engine for modern JavaScript, WebGL, media, and embeds without distributing a
custom executable. It is not physically embedded inside the HTA.

## Important behavior

- Microsoft Edge is required and is checked before the token is activated.
- Existing Share Browser and Project Z computer connections are reused.
- Only the dedicated Edge profile/process is closed when the session finishes.
- Standard mode keeps the dedicated profile. Privacy mode uses and removes a
  session-specific profile where Windows file locks permit.
- Incognito is not used.
- The connection is direct. This is not a VPN or proxy and does not hide an IP.
- Edge and Microsoft Defender protections remain active. Project Z Modern does
  not weaken them, but an HTA cannot promise that every website-generated
  download will be blocked without an administrator-managed Edge policy.
- The existing Project Z 0.1.5 download remains available and unchanged.

Extract the ZIP and open `ProjectZModern.hta`. Keep its controller open while
using the dedicated Microsoft Edge window.
