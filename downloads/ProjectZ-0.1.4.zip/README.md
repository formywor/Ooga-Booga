# Project Z 0.1.4 — standalone HTA beta

Project Z is a single Windows `.hta` browser file operated by ScriptNovaa. It
shares ScriptNovaa accounts, points, the one-computer registration, and the
two-unused-token limit with Share Browser. Project Z uses separate `Z-` tokens.

## Open Project Z

Extract `ProjectZ-0.1.4.zip`, then open `ProjectZ.hta`. There is no companion
executable, installer, .NET requirement, PowerShell window, or background service.
The HTA hosts Windows' built-in WebBrowser component and offers Snova Search,
Google, DuckDuckGo, and Bing as search choices. Snova Search includes a guarded,
reader-friendly view of Wikipedia results. The **Modern** button sends the
current address to the user's default modern browser when a page needs newer
JavaScript.

Some modern websites no longer support the legacy Windows web component and may
display a compatibility warning or fail to sign in. That is an unavoidable limit
of requiring a pure HTA; Project Z does not claim to contain Chromium or WebView2.

## Connection and tokens

1. Sign in at https://scriptnovaa.com and confirm your recovery code.
2. If Share Browser is already connected for the same Windows user, Project Z
   checks its saved credential and exact saved device proof automatically.
3. Otherwise, request the first one-time connection code on `/tokens`, enter the
   complete code, and select **Connect this computer**. Project Z saves the exact
   proof used during pairing so later checks match the API.
4. On `/tokens`, select Project Z and create a Z token with shared points.
5. Enter the Z token, select a search provider and data mode, then start.

Connection codes are single-use. Replacement codes still require Support
approval. An empty code is rejected locally and is never sent to the API.

## Session rules

- A Z token starts only after the API accepts it.
- Tokens cannot pause or resume.
- Closing Project Z, ending the session, expiration, or failed authorization
  permanently finishes the active token.
- A heartbeat is sent every 10 seconds against a 30-second server lease.
- After a session ends, Project Z returns to the token screen.
- Standard mode uses the Windows web component normally. Privacy mode requests
  no-history and no-cache navigation where Windows permits, but it is not a
  forensic-erasure guarantee.

Project Z is a direct connection. It does not provide a VPN, proxy, FAST route,
or IP changer. Websites and the user's network can see the normal public IP.

## Publish

1. Upload `outputs/api` to the API repository and let Vercel deploy version 0.1.4.
2. Upload `outputs/main-website` to the GitHub Pages website repository.
3. The website download is `downloads/ProjectZ-0.1.4.zip`.

The API update must be published before the new HTA because outdated versions
are intentionally rejected. Test connection, a short Z token, all four search
providers, heartbeat failure, expiration, and window closing before broad release.
