# Project Z 0.1.0 — free direct-connection beta

Project Z shares ScriptNovaa accounts, points and the one-computer registration
with Share Browser. It uses separate `Z-` tokens. Existing Share Browser tokens
remain valid only in Share Browser.

## What to distribute

Distribute the complete `ProjectZ-0.1.0.zip`, not just the HTA or EXE. Extract
everything together, then open `ProjectZ.hta` and press **Open Project Z**, or
open `ProjectZ.exe` directly. The HTA is a launcher; the modern embedded browser
is a native Windows companion using Microsoft's WebView2 engine.

Requires Windows 10/11, .NET Framework 4.8 and the Evergreen Microsoft Edge
WebView2 Runtime. If missing, obtain the runtime from Microsoft's official
WebView2 website. No administrator privileges are requested by Project Z.
The beta executable is unsigned. Do not disable security controls to run it.

## Connection and tokens

1. Sign up/sign in at https://scriptnovaa.com and confirm your recovery code.
2. If Share Browser is already paired under this Windows user, Project Z reads
   that saved connection, compares the current hardware proof and checks it with
   the API. It does not silently register another computer.
3. Otherwise generate your first connection code on `/tokens` and enter it in Z.
   Replacement codes still require a Support ticket approved by staff.
4. Select **Project Z** on `/tokens`, spend points, and copy the resulting Z token.
5. Choose Google, DuckDuckGo or Bing and Standard or Privacy local-data mode.
6. Start. Browser initialization and process isolation are checked before token
   activation. On expiry/close/revocation, the browser is destroyed and the token
   entry screen returns. Tokens cannot pause or resume.

The normal pricing menu is shared, with no extra FAST charge. At most two unused
tokens and one active session per account apply across both products.

**There is no VPN/proxy/IP changer in this release.** All browsing is direct.
No paid service, new hosting subscription, or model API has been added. Existing
Firebase/Vercel quotas still apply; unlimited free hosting is not promised.

Standard keeps sign-ins in a separate per-account local profile. Privacy uses
a disposable profile without Incognito. No history-free or forensic-erasure
guarantee is made. The app attempts deletion at session end; crashes can leave
temporary files. Downloads, external-app schemes, extensions and device
permissions are disabled for this beta. New-window links open in the same view;
some sites do not support embedded sign-in.

Saved Z credentials use Windows DPAPI bound to the Windows user and current
device proof, in `%LOCALAPPDATA%\ScriptNovaa\ProjectZ\connection.bin`. The
legacy Share Browser registry credential is imported but not modified. A new
Z-only pairing is not written into Share Browser's plaintext registry storage.
To connect Share Browser afterward, use its existing connection if available or
request a replacement code through Support on the same account/device.

## Architecture and security boundaries

- Website: GitHub Pages, separate `/project-z` download page.
- Existing API: `https://api.scriptnovaa.com`, `/api/z/*` routes in the same
  Express deployment. No additional Vercel function per route is required.
- Shared pairing completion atomically consumes a code, binds the device,
  records the once-only bonus and creates the launcher credential.
- Native controls own authentication, address bar, settings, lifecycle and timers.
  Untrusted websites get no host objects or privileged web-message bridge.
- No arbitrary server commands, downloaded JavaScript modules or old custom UA.
  WebView2 uses its current default identity. Server configuration only provides
  allowlisted search choices, timing and version compatibility.
- Windows Job Objects close the isolated WebView2 process group when Z exits or
  crashes. Regular Chrome/Edge processes are not targeted.
- A 30-second server lease and 10-second heartbeat enforce authorization. Local
  timers use elapsed time, not the editable wall clock. A dead lease cannot revive.
  No scheduled/paid cleanup function is required: the next start finalizes a dead
  Z session. Until then the database may still label it ACTIVE, but validation
  will reject it after the lease deadline.
- Computer identity and desktop timers are not tamper-proof against the machine
  owner. No client-delivered UI can be made secret. Direct access to the public
  internet is not made token-exclusive by this app.

## Build on Windows

Install a supported .NET SDK, then run `./build.ps1`. NuGet dependencies are
version-locked. The SDK compiles against .NET Framework reference assemblies;
users do not need the SDK. `--self-test` checks WMI identity, blank embedded-browser
initialization, job assignment and temporary-profile cleanup without contacting
production accounts or spending points. It requires the WebView2 Runtime.

The `.github/workflows/build.yml` workflow builds a downloadable ZIP on a Windows
runner when the contents of this source folder are uploaded to their own repo.
Codespaces can edit these files, but Windows is required to run the companion.

## Publish

1. Deploy the updated `outputs/api` contents to the existing API repository.
2. Upload `outputs/main-website` contents, including the packaged ZIP, to Pages.
3. Keep `outputs/project-z` as the source/build project; it is not Vercel backend code.
4. Validate actual pairing, a short session, all three search providers, normal
   and temporary profiles, closing, offline expiry and account revocation on
   Windows before advertising the beta broadly. Local tests do not substitute
   for this deployed end-to-end check.

Third-party SDK redistribution terms accompany the ZIP. The WebView2 Runtime is
installed and updated separately by Microsoft; it is not included in the ZIP.
