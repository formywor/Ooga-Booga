# Galaxy Browser 1.0.1

Galaxy Browser is a standalone Windows HTA from ScriptNovaa. It does not
replace Share Browser or Project Z. All three products use the same connected
computer and ScriptNovaa account, but Galaxy requires its own `GALAXY-` token.

Galaxy 1.0 includes:

- Snova search inside the HTA. Search queries are relayed to DuckDuckGo with an
  automatic fallback. Destination websites open directly.
- Google and Bing selections now open the selected provider correctly. When a
  Windows installation no longer provides the legacy embedded browser control,
  Galaxy opens search in the installed modern browser while keeping the timed
  Galaxy session active.
- A locally rendered ScriptNovaa sponsored-partner demonstration. ScriptNovaa
  is the demonstration partner until outside partners are available.
- Managed Chrome or Microsoft Edge sessions in a dedicated Galaxy profile.
- Standard and temporary local-data modes.
- Single-use and Multi-use Galaxy tokens. Multi-use sessions can be reopened on
  the same connected computer until their purchased time expires.

Galaxy is not a VPN. Destination websites see the user's normal public IP.
Partner placement does not create points or simulate advertising clicks.

Extract the official ZIP and open `GalaxyBrowser.hta`. Download only from
`https://scriptnovaa.com/galaxy-browser`.
